import React from 'react'

export const Number = (props) => {
    return (
        <div>
            <p>{props.id}</p>
        </div>
    )
}
export default Number;