import React from 'react'

export const Home = () => {
    return (
        <div>
          <h1>Welcome</h1>  
        </div>
    )
}
export default Home;